
def package_demo():
    print("hello from my new package")

